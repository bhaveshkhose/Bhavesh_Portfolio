const TESTIMONIALS = [
  {
    quote: "We replaced three point solutions with Sentinel and cut our mean time to detect from 14 hours to under 90 seconds. The behavioral AI catches things our previous SIEM couldn't even model.",
    name: 'Diane Kowalski',
    title: 'Chief Information Security Officer',
    company: 'Northgate Financial Group',
    initials: 'DK',
  },
  {
    quote: "Sentinel's automated playbooks have handled 94% of our security incidents without analyst intervention this quarter. Our team now focuses on what actually matters — the 6% that requires human judgment.",
    name: 'Marcus Chen',
    title: 'VP of Cybersecurity Operations',
    company: 'Vantara Defense Systems',
    initials: 'MC',
  },
  {
    quote: "The attack surface management module alone found 140 exposed assets we had zero visibility into. Within 48 hours of deployment, we'd closed critical gaps that had existed for over two years.",
    name: 'Priya Nambiar',
    title: 'Director of Security Engineering',
    company: 'Axiom Health Systems',
    initials: 'PN',
  },
]

export default function Testimonials() {
  return (
    <section style={{ background: '#0d1117', padding: '120px 24px', borderTop: '1px solid rgba(0,217,255,0.08)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 72 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#00d9ff', letterSpacing: '0.12em', marginBottom: 16 }}>
            CUSTOMER STORIES
          </div>
          <h2 style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 'clamp(32px, 4vw, 52px)',
            fontWeight: 700, color: '#e2e8f0', letterSpacing: '-0.03em', lineHeight: 1.1,
          }}>
            Security teams who chose<br />to stop reacting.
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 24 }}>
          {TESTIMONIALS.map((t, i) => (
            <div key={i} style={{
              background: '#07090e',
              border: '1px solid rgba(0,217,255,0.1)',
              borderRadius: 16,
              padding: '36px 32px',
              transition: 'border-color 0.2s',
              cursor: 'default',
            }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(0,217,255,0.3)')}
              onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(0,217,255,0.1)')}
            >
              {/* Quote mark */}
              <div style={{ fontFamily: "Georgia, serif", fontSize: 64, color: '#00d9ff', opacity: 0.2, lineHeight: 1, marginBottom: 8 }}>"</div>
              <p style={{ color: '#94a3b8', fontSize: 15, lineHeight: 1.8, marginBottom: 32 }}>{t.quote}</p>
              <div style={{ display: 'flex', gap: 14, alignItems: 'center', borderTop: '1px solid rgba(0,217,255,0.08)', paddingTop: 24 }}>
                <div style={{
                  width: 44, height: 44, borderRadius: '50%',
                  background: 'rgba(0,217,255,0.1)',
                  border: '1px solid rgba(0,217,255,0.2)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 600, color: '#00d9ff',
                  flexShrink: 0,
                }}>{t.initials}</div>
                <div>
                  <div style={{ color: '#e2e8f0', fontSize: 14, fontWeight: 600 }}>{t.name}</div>
                  <div style={{ color: '#64748b', fontSize: 12 }}>{t.title}, {t.company}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
