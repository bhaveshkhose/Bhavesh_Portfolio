export default function Nav() {
  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 50,
      borderBottom: '1px solid rgba(0,217,255,0.1)',
      backgroundColor: 'rgba(7,9,14,0.85)',
      backdropFilter: 'blur(12px)',
    }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64 }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, position: 'relative' }}>
            <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <polygon points="16,2 30,9 30,23 16,30 2,23 2,9" stroke="#00d9ff" strokeWidth="1.5" fill="rgba(0,217,255,0.06)" />
              <polygon points="16,8 24,12 24,20 16,24 8,20 8,12" stroke="#00d9ff" strokeWidth="1" fill="rgba(0,217,255,0.1)" />
              <circle cx="16" cy="16" r="3" fill="#00d9ff" />
            </svg>
          </div>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 600, fontSize: 17, color: '#e2e8f0', letterSpacing: '-0.02em' }}>
            SENTINEL<span style={{ color: '#00d9ff' }}>.AI</span>
          </span>
        </div>

        {/* Desktop links */}
        <div style={{ display: 'flex', gap: 32, alignItems: 'center' }} className="hidden-mobile">
          {['Platform', 'Solutions', 'Pricing', 'Docs', 'Blog'].map(link => (
            <a key={link} href="#" style={{ color: '#94a3b8', fontSize: 14, fontWeight: 500, textDecoration: 'none', transition: 'color 0.2s' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#e2e8f0')}
              onMouseLeave={e => (e.currentTarget.style.color = '#94a3b8')}
            >{link}</a>
          ))}
        </div>

        {/* CTA */}
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <a href="#" style={{ color: '#94a3b8', fontSize: 14, fontWeight: 500, textDecoration: 'none' }}
            onMouseEnter={e => (e.currentTarget.style.color = '#e2e8f0')}
            onMouseLeave={e => (e.currentTarget.style.color = '#94a3b8')}
          >Sign in</a>
          <button style={{
            background: '#00d9ff', color: '#07090e', border: 'none', borderRadius: 6,
            padding: '8px 18px', fontSize: 14, fontWeight: 600, cursor: 'pointer',
            fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.02em',
            transition: 'opacity 0.2s',
          }}
            onMouseEnter={e => (e.currentTarget.style.opacity = '0.85')}
            onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
          >
            Get Demo
          </button>
        </div>
      </div>
    </nav>
  )
}
