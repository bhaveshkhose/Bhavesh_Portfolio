const LOGOS = [
  { name: 'Northgate Financial', abbr: 'NGF' },
  { name: 'Axiom Health Systems', abbr: 'AHS' },
  { name: 'Vantara Defense', abbr: 'VDG' },
  { name: 'Crestline Energy', abbr: 'CLE' },
  { name: 'Meridian Logistics', abbr: 'MLG' },
  { name: 'Helios Aerospace', abbr: 'HLS' },
]

export default function TrustBar() {
  return (
    <section style={{ borderTop: '1px solid rgba(0,217,255,0.08)', borderBottom: '1px solid rgba(0,217,255,0.08)', padding: '32px 24px', background: 'rgba(13,17,23,0.5)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <p style={{ textAlign: 'center', fontSize: 12, color: '#64748b', fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.12em', marginBottom: 28 }}>
          TRUSTED BY SECURITY-FIRST ENTERPRISES WORLDWIDE
        </p>
        <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '16px 48px', alignItems: 'center' }}>
          {LOGOS.map(({ name, abbr }) => (
            <div key={abbr} style={{ display: 'flex', alignItems: 'center', gap: 8, opacity: 0.5, transition: 'opacity 0.2s', cursor: 'default' }}
              onMouseEnter={e => (e.currentTarget.style.opacity = '0.9')}
              onMouseLeave={e => (e.currentTarget.style.opacity = '0.5')}
            >
              <div style={{
                width: 28, height: 28, borderRadius: 6,
                background: 'rgba(0,217,255,0.1)',
                border: '1px solid rgba(0,217,255,0.2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: "'JetBrains Mono', monospace", fontSize: 8, fontWeight: 700, color: '#00d9ff',
              }}>{abbr[0]}</div>
              <span style={{ color: '#94a3b8', fontSize: 14, fontWeight: 500 }}>{name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
