const STEPS = [
  {
    num: '01',
    title: 'Connect Everything',
    desc: 'Deploy the Sentinel collector via API, agent, or agentless integration. Connects to your cloud providers, endpoints, identity systems, and SaaS tools in under 15 minutes. No forklift migration.',
    detail: '200+ native integrations · Agentless cloud · SIEM/SOAR compatible',
  },
  {
    num: '02',
    title: 'Baseline & Learn',
    desc: 'Sentinel\'s behavioral AI spends the first 72 hours learning what "normal" looks like for your environment. It builds per-entity baselines across users, devices, workloads, and network flows.',
    detail: 'Peer-group analysis · Temporal patterns · Workload profiling',
  },
  {
    num: '03',
    title: 'Detect & Correlate',
    desc: 'Anomalies are scored in real time and correlated across kill-chain stages. What looks like isolated noise becomes a high-confidence attack story — with MITRE ATT&CK mapping.',
    detail: 'Multi-stage correlation · Threat scoring · Attack narrative',
  },
  {
    num: '04',
    title: 'Respond & Contain',
    desc: 'Automated playbooks fire within milliseconds. Analysts get a complete investigation timeline, one-click containment, and a full audit trail — all in a single pane of glass.',
    detail: 'Sub-2ms automation · Full forensic timeline · SOAR integration',
  },
]

export default function HowItWorks() {
  return (
    <section style={{ padding: '120px 24px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ marginBottom: 72 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#00d9ff', letterSpacing: '0.12em', marginBottom: 16 }}>
            HOW IT WORKS
          </div>
          <h2 style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 'clamp(32px, 4vw, 52px)',
            fontWeight: 700, color: '#e2e8f0', letterSpacing: '-0.03em', lineHeight: 1.1,
          }}>
            From deploy to detected<br />in under 15 minutes.
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 0, position: 'relative' }}>
          {/* Connector line */}
          <div style={{
            position: 'absolute', top: 28, left: '12.5%', right: '12.5%', height: 1,
            background: 'linear-gradient(90deg, transparent, rgba(0,217,255,0.3) 20%, rgba(0,217,255,0.3) 80%, transparent)',
          }} />

          {STEPS.map((step, i) => (
            <div key={i} style={{ padding: '0 24px', position: 'relative' }}>
              {/* Step number bubble */}
              <div style={{
                width: 56, height: 56, borderRadius: '50%',
                background: '#07090e',
                border: '1px solid rgba(0,217,255,0.3)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: "'JetBrains Mono', monospace", fontSize: 16, fontWeight: 700, color: '#00d9ff',
                marginBottom: 28, position: 'relative', zIndex: 1,
              }}>
                {step.num}
              </div>

              <h3 style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 18, fontWeight: 600, color: '#e2e8f0', marginBottom: 12, letterSpacing: '-0.02em' }}>
                {step.title}
              </h3>
              <p style={{ color: '#64748b', fontSize: 14, lineHeight: 1.8, marginBottom: 20 }}>
                {step.desc}
              </p>
              <div style={{
                fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#00d9ff',
                borderTop: '1px solid rgba(0,217,255,0.15)', paddingTop: 16, lineHeight: 1.8,
              }}>
                {step.detail.split(' · ').map((d, j) => (
                  <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ color: '#00d9ff', opacity: 0.5 }}>›</span> {d}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
