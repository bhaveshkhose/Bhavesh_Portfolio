import { useEffect, useRef, useState } from 'react'

const LINES = [
  '> threat_scan --realtime --depth=full',
  '  scanning 847,293 endpoints...',
  '  [████████████░░░░] 74% complete',
  '  anomaly detected: lateral movement (CVE-2024-3891)',
  '  confidence: 97.4% | severity: CRITICAL',
  '> auto_response --isolate --alert',
  '  isolating node: 10.14.22.87',
  '  incident #INC-20240715-0042 created',
  '  security team notified | ETA: 00:00:43',
  '> threat neutralized. system nominal.',
]

function Terminal() {
  const [visibleLines, setVisibleLines] = useState<number>(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setVisibleLines(v => {
        if (v >= LINES.length) {
          setTimeout(() => setVisibleLines(0), 2000)
          clearInterval(interval)
          return v
        }
        return v + 1
      })
    }, 500)
    return () => clearInterval(interval)
  }, [visibleLines])

  return (
    <div style={{
      background: '#0d1117',
      border: '1px solid rgba(0,217,255,0.2)',
      borderRadius: 12,
      padding: '20px 24px',
      fontFamily: "'JetBrains Mono', monospace",
      fontSize: 13,
      lineHeight: 1.7,
      maxWidth: 520,
      width: '100%',
      boxShadow: '0 0 60px rgba(0,217,255,0.08), 0 0 120px rgba(99,102,241,0.05)',
    }}>
      {/* Window chrome */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {['#ff5f57', '#febc2e', '#28c840'].map((c, i) => (
          <div key={i} style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: c, opacity: 0.9 }} />
        ))}
        <span style={{ color: '#64748b', fontSize: 11, marginLeft: 8, alignSelf: 'center' }}>sentinel — threat monitor</span>
      </div>
      {LINES.slice(0, visibleLines).map((line, i) => (
        <div key={i} style={{
          color: line.startsWith('>') ? '#00d9ff' : line.includes('CRITICAL') ? '#f87171' : line.includes('neutralized') ? '#34d399' : '#94a3b8',
          fontWeight: line.startsWith('>') ? 500 : 400,
        }}>
          {line}
        </div>
      ))}
      {visibleLines < LINES.length && (
        <span style={{ color: '#00d9ff' }}>█</span>
      )}
    </div>
  )
}

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    let animId: number

    const resize = () => {
      canvas.width = canvas.offsetWidth
      canvas.height = canvas.offsetHeight
    }
    resize()
    window.addEventListener('resize', resize)

    const nodes: { x: number; y: number; vx: number; vy: number; active: boolean }[] = Array.from({ length: 40 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      active: Math.random() < 0.15,
    }))

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      nodes.forEach(n => {
        n.x += n.vx
        n.y += n.vy
        if (n.x < 0 || n.x > canvas.width) n.vx *= -1
        if (n.y < 0 || n.y > canvas.height) n.vy *= -1
      })

      // Draw connections
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x
          const dy = nodes[i].y - nodes[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < 120) {
            const alpha = (1 - dist / 120) * 0.15
            ctx.beginPath()
            ctx.strokeStyle = `rgba(0,217,255,${alpha})`
            ctx.lineWidth = 0.5
            ctx.moveTo(nodes[i].x, nodes[i].y)
            ctx.lineTo(nodes[j].x, nodes[j].y)
            ctx.stroke()
          }
        }
      }

      // Draw nodes
      nodes.forEach(n => {
        ctx.beginPath()
        ctx.arc(n.x, n.y, n.active ? 3 : 1.5, 0, Math.PI * 2)
        ctx.fillStyle = n.active ? 'rgba(248,113,113,0.9)' : 'rgba(0,217,255,0.4)'
        ctx.fill()
        if (n.active) {
          ctx.beginPath()
          ctx.arc(n.x, n.y, 8, 0, Math.PI * 2)
          ctx.fillStyle = 'rgba(248,113,113,0.05)'
          ctx.fill()
        }
      })

      animId = requestAnimationFrame(draw)
    }
    draw()
    return () => {
      cancelAnimationFrame(animId)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <section style={{
      position: 'relative',
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      overflow: 'hidden',
      paddingTop: 64,
    }}>
      {/* Animated network canvas */}
      <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.6 }} />

      {/* Grid overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: 'linear-gradient(rgba(0,217,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,217,255,0.04) 1px, transparent 1px)',
        backgroundSize: '60px 60px',
      }} />

      {/* Radial gradient vignette */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse 80% 60% at 50% 50%, transparent 30%, #07090e 100%)',
      }} />

      <div style={{ position: 'relative', maxWidth: 1280, margin: '0 auto', padding: '80px 24px', display: 'flex', gap: 80, alignItems: 'center', flexWrap: 'wrap' }}>
        {/* Left: copy */}
        <div style={{ flex: '1 1 480px' }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            border: '1px solid rgba(0,217,255,0.25)', borderRadius: 100,
            padding: '5px 14px', marginBottom: 32,
            background: 'rgba(0,217,255,0.06)',
          }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#00d9ff', boxShadow: '0 0 8px #00d9ff' }} />
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#00d9ff', letterSpacing: '0.08em' }}>
              AI THREAT DETECTION — LIVE
            </span>
          </div>

          <h1 style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 'clamp(40px, 5.5vw, 72px)',
            fontWeight: 700,
            lineHeight: 1.05,
            color: '#e2e8f0',
            letterSpacing: '-0.03em',
            marginBottom: 24,
          }}>
            Threats Stopped.<br />
            <span style={{ color: '#00d9ff' }}>Before</span> They<br />
            Strike.
          </h1>

          <p style={{ color: '#94a3b8', fontSize: 18, lineHeight: 1.7, maxWidth: 480, marginBottom: 40 }}>
            Sentinel's autonomous AI monitors your entire attack surface in real time — detecting, correlating, and neutralizing advanced threats with sub-2ms response times.
          </p>

          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <button style={{
              background: '#00d9ff', color: '#07090e',
              border: 'none', borderRadius: 8, padding: '14px 28px',
              fontSize: 15, fontWeight: 700, cursor: 'pointer',
              fontFamily: "'JetBrains Mono', monospace", letterSpacing: '0.02em',
              transition: 'all 0.2s', boxShadow: '0 0 30px rgba(0,217,255,0.3)',
            }}
              onMouseEnter={e => { e.currentTarget.style.boxShadow = '0 0 50px rgba(0,217,255,0.5)'; e.currentTarget.style.transform = 'translateY(-1px)' }}
              onMouseLeave={e => { e.currentTarget.style.boxShadow = '0 0 30px rgba(0,217,255,0.3)'; e.currentTarget.style.transform = 'translateY(0)' }}
            >
              Request Demo
            </button>
            <button style={{
              background: 'transparent', color: '#e2e8f0',
              border: '1px solid rgba(226,232,240,0.2)', borderRadius: 8, padding: '14px 28px',
              fontSize: 15, fontWeight: 500, cursor: 'pointer',
              transition: 'all 0.2s',
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(0,217,255,0.4)'; e.currentTarget.style.color = '#00d9ff' }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(226,232,240,0.2)'; e.currentTarget.style.color = '#e2e8f0' }}
            >
              View Platform →
            </button>
          </div>

          <div style={{ display: 'flex', gap: 32, marginTop: 52, flexWrap: 'wrap' }}>
            {[
              { val: '99.7%', label: 'Detection Rate' },
              { val: '<2ms', label: 'Response Time' },
              { val: '500M+', label: 'Events / Day' },
            ].map(({ val, label }) => (
              <div key={label}>
                <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 28, fontWeight: 700, color: '#00d9ff' }}>{val}</div>
                <div style={{ fontSize: 13, color: '#64748b', marginTop: 2 }}>{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: terminal */}
        <div style={{ flex: '1 1 380px', display: 'flex', justifyContent: 'center' }}>
          <Terminal />
        </div>
      </div>

      {/* Bottom fade */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 120, background: 'linear-gradient(transparent, #07090e)' }} />
    </section>
  )
}
