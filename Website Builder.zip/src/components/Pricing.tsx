import { useState } from 'react'

const PLANS = [
  {
    name: 'Protect',
    price: { monthly: 299, annual: 249 },
    desc: 'For growing security teams securing up to 500 endpoints.',
    features: [
      'Up to 500 endpoints',
      'Real-time threat detection',
      'Behavioral anomaly detection',
      '50M events / day',
      '5 automated playbooks',
      'SOC 2 compliance reporting',
      'Email & Slack alerts',
      '9×5 support',
    ],
    highlight: false,
    cta: 'Start Free Trial',
  },
  {
    name: 'Command',
    price: { monthly: 899, annual: 749 },
    desc: 'For enterprise SOC teams with complex, multi-cloud environments.',
    features: [
      'Up to 5,000 endpoints',
      'Everything in Protect',
      'Zero-day prevention engine',
      '500M events / day',
      'Unlimited playbooks',
      'Attack surface management',
      'MITRE ATT&CK mapping',
      'SIEM / SOAR integration',
      '24×7 support + CSM',
    ],
    highlight: true,
    cta: 'Request Demo',
  },
  {
    name: 'Sovereign',
    price: { monthly: null, annual: null },
    desc: 'For critical infrastructure and defense-grade security requirements.',
    features: [
      'Unlimited endpoints',
      'Everything in Command',
      'Air-gapped deployment',
      'Custom AI model training',
      'Red team simulation',
      'Dedicated incident response',
      'SLA: 15-min response',
      'On-site deployment support',
    ],
    highlight: false,
    cta: 'Contact Sales',
  },
]

export default function Pricing() {
  const [annual, setAnnual] = useState(true)

  return (
    <section style={{ padding: '120px 24px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 72 }}>
          <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#00d9ff', letterSpacing: '0.12em', marginBottom: 16 }}>
            PRICING
          </div>
          <h2 style={{
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: 'clamp(32px, 4vw, 52px)',
            fontWeight: 700, color: '#e2e8f0', letterSpacing: '-0.03em', lineHeight: 1.1, marginBottom: 32,
          }}>
            Transparent pricing.<br />No per-alert taxes.
          </h2>

          {/* Toggle */}
          <div style={{ display: 'inline-flex', background: '#0d1117', border: '1px solid rgba(0,217,255,0.15)', borderRadius: 8, padding: 4, gap: 4 }}>
            {['Monthly', 'Annual'].map(mode => (
              <button key={mode} onClick={() => setAnnual(mode === 'Annual')} style={{
                padding: '8px 20px', borderRadius: 6, border: 'none', cursor: 'pointer',
                background: (mode === 'Annual') === annual ? '#00d9ff' : 'transparent',
                color: (mode === 'Annual') === annual ? '#07090e' : '#64748b',
                fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 600,
                transition: 'all 0.2s',
              }}>
                {mode}
                {mode === 'Annual' && <span style={{ marginLeft: 6, fontSize: 10, opacity: 0.8 }}>−17%</span>}
              </button>
            ))}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 24 }}>
          {PLANS.map((plan, i) => (
            <div key={i} style={{
              background: plan.highlight ? 'rgba(0,217,255,0.05)' : '#0d1117',
              border: plan.highlight ? '1px solid rgba(0,217,255,0.4)' : '1px solid rgba(0,217,255,0.1)',
              borderRadius: 16,
              padding: '40px 36px',
              position: 'relative',
              transition: 'border-color 0.2s',
            }}>
              {plan.highlight && (
                <div style={{
                  position: 'absolute', top: -1, left: '50%', transform: 'translateX(-50%)',
                  background: '#00d9ff', color: '#07090e',
                  fontFamily: "'JetBrains Mono', monospace", fontSize: 11, fontWeight: 700,
                  padding: '4px 14px', borderRadius: '0 0 8px 8px', letterSpacing: '0.08em',
                }}>MOST POPULAR</div>
              )}

              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 14, color: '#00d9ff', fontWeight: 600, marginBottom: 8 }}>
                {plan.name}
              </div>
              <div style={{ marginBottom: 20 }}>
                {plan.price.monthly ? (
                  <div>
                    <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 44, fontWeight: 700, color: '#e2e8f0' }}>
                      ${annual ? plan.price.annual : plan.price.monthly}
                    </span>
                    <span style={{ color: '#64748b', fontSize: 14 }}>/mo</span>
                    {annual && <span style={{ display: 'block', color: '#64748b', fontSize: 12, marginTop: 4 }}>billed annually</span>}
                  </div>
                ) : (
                  <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 36, fontWeight: 700, color: '#e2e8f0' }}>Custom</div>
                )}
              </div>
              <p style={{ color: '#64748b', fontSize: 14, lineHeight: 1.6, marginBottom: 32 }}>{plan.desc}</p>

              <button style={{
                width: '100%',
                background: plan.highlight ? '#00d9ff' : 'transparent',
                color: plan.highlight ? '#07090e' : '#e2e8f0',
                border: plan.highlight ? 'none' : '1px solid rgba(226,232,240,0.2)',
                borderRadius: 8, padding: '13px 0',
                fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 600,
                cursor: 'pointer', marginBottom: 32, transition: 'all 0.2s',
              }}
                onMouseEnter={e => {
                  if (!plan.highlight) { e.currentTarget.style.borderColor = 'rgba(0,217,255,0.4)'; e.currentTarget.style.color = '#00d9ff' }
                  else e.currentTarget.style.opacity = '0.85'
                }}
                onMouseLeave={e => {
                  if (!plan.highlight) { e.currentTarget.style.borderColor = 'rgba(226,232,240,0.2)'; e.currentTarget.style.color = '#e2e8f0' }
                  else e.currentTarget.style.opacity = '1'
                }}
              >
                {plan.cta}
              </button>

              <div style={{ borderTop: '1px solid rgba(0,217,255,0.08)', paddingTop: 28 }}>
                {plan.features.map((f, j) => (
                  <div key={j} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 12 }}>
                    <span style={{ color: '#00d9ff', marginTop: 1, flexShrink: 0 }}>✓</span>
                    <span style={{ color: '#94a3b8', fontSize: 14 }}>{f}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
