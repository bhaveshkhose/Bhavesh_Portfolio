export default function CTABanner() {
  return (
    <section style={{
      padding: '100px 24px',
      background: '#0d1117',
      borderTop: '1px solid rgba(0,217,255,0.08)',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Background glow */}
      <div style={{
        position: 'absolute', top: '50%', left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 600, height: 300,
        background: 'radial-gradient(ellipse, rgba(0,217,255,0.06) 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />

      <div style={{ maxWidth: 720, margin: '0 auto', textAlign: 'center', position: 'relative' }}>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#00d9ff', letterSpacing: '0.12em', marginBottom: 24 }}>
          START IN MINUTES
        </div>
        <h2 style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 'clamp(32px, 4vw, 56px)',
          fontWeight: 700, color: '#e2e8f0', letterSpacing: '-0.03em', lineHeight: 1.1, marginBottom: 24,
        }}>
          Your attackers aren't<br />waiting. Neither should you.
        </h2>
        <p style={{ color: '#64748b', fontSize: 17, lineHeight: 1.7, marginBottom: 48 }}>
          Deploy Sentinel in under 15 minutes. No agents required for cloud environments. Full visibility from day one — and a 30-day risk-free guarantee.
        </p>
        <div style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button style={{
            background: '#00d9ff', color: '#07090e',
            border: 'none', borderRadius: 8, padding: '16px 36px',
            fontSize: 16, fontWeight: 700, cursor: 'pointer',
            fontFamily: "'JetBrains Mono', monospace",
            boxShadow: '0 0 40px rgba(0,217,255,0.3)',
            transition: 'all 0.2s',
          }}
            onMouseEnter={e => { e.currentTarget.style.boxShadow = '0 0 60px rgba(0,217,255,0.5)'; e.currentTarget.style.transform = 'translateY(-2px)' }}
            onMouseLeave={e => { e.currentTarget.style.boxShadow = '0 0 40px rgba(0,217,255,0.3)'; e.currentTarget.style.transform = 'translateY(0)' }}
          >
            Start Free Trial
          </button>
          <button style={{
            background: 'transparent', color: '#e2e8f0',
            border: '1px solid rgba(226,232,240,0.2)', borderRadius: 8, padding: '16px 36px',
            fontSize: 16, fontWeight: 500, cursor: 'pointer',
            transition: 'all 0.2s',
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(0,217,255,0.4)'; e.currentTarget.style.color = '#00d9ff' }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(226,232,240,0.2)'; e.currentTarget.style.color = '#e2e8f0' }}
          >
            Talk to Sales
          </button>
        </div>
        <p style={{ color: '#64748b', fontSize: 13, marginTop: 24 }}>
          No credit card required · SOC 2 Type II certified · GDPR compliant
        </p>
      </div>
    </section>
  )
}
