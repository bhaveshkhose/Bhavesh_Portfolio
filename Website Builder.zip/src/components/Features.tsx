const FEATURES = [
  {
    icon: '⬡',
    title: 'Real-Time Threat Intelligence',
    desc: 'Correlates signals from 200+ threat feeds with your environment to surface actionable intelligence — not noise.',
    tag: 'DETECTION',
    color: '#00d9ff',
  },
  {
    icon: '◈',
    title: 'Behavioral Anomaly Detection',
    desc: 'Establishes dynamic baselines per user, device, and workload. Flags deviations that signature-based tools miss entirely.',
    tag: 'ANALYSIS',
    color: '#6366f1',
  },
  {
    icon: '⬟',
    title: 'Automated Incident Response',
    desc: 'Pre-built and custom playbooks execute in milliseconds — isolating nodes, revoking sessions, and creating tickets automatically.',
    tag: 'RESPONSE',
    color: '#00d9ff',
  },
  {
    icon: '◉',
    title: 'Zero-Day Exploit Prevention',
    desc: 'ML models trained on exploit technique patterns catch novel attacks before CVEs are published. No signature required.',
    tag: 'PREVENTION',
    color: '#f59e0b',
  },
  {
    icon: '⬡',
    title: 'Compliance Automation',
    desc: 'Continuous evidence collection for SOC 2, ISO 27001, HIPAA, PCI-DSS. Audit-ready reports generated on demand.',
    tag: 'COMPLIANCE',
    color: '#34d399',
  },
  {
    icon: '◈',
    title: 'Attack Surface Management',
    desc: 'Continuously discovers and scores every exposed asset — cloud, on-prem, SaaS, and shadow IT — from an attacker\'s perspective.',
    tag: 'VISIBILITY',
    color: '#6366f1',
  },
]

export default function Features() {
  return (
    <section style={{ padding: '120px 24px', maxWidth: 1280, margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: 72 }}>
        <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#00d9ff', letterSpacing: '0.12em', marginBottom: 16 }}>
          PLATFORM CAPABILITIES
        </div>
        <h2 style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 'clamp(32px, 4vw, 52px)',
          fontWeight: 700,
          color: '#e2e8f0',
          letterSpacing: '-0.03em',
          lineHeight: 1.1,
          marginBottom: 20,
        }}>
          One platform.<br />Total threat coverage.
        </h2>
        <p style={{ color: '#64748b', fontSize: 18, maxWidth: 520, margin: '0 auto' }}>
          Purpose-built AI modules that work together to give your team complete visibility and control.
        </p>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
        gap: 1,
        background: 'rgba(0,217,255,0.08)',
        border: '1px solid rgba(0,217,255,0.08)',
        borderRadius: 16,
        overflow: 'hidden',
      }}>
        {FEATURES.map((f, i) => (
          <div key={i} style={{
            background: '#07090e',
            padding: '36px 32px',
            transition: 'background 0.2s',
            cursor: 'default',
          }}
            onMouseEnter={e => (e.currentTarget.style.background = '#0d1117')}
            onMouseLeave={e => (e.currentTarget.style.background = '#07090e')}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 10,
                background: `${f.color}14`,
                border: `1px solid ${f.color}33`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 22, color: f.color,
              }}>{f.icon}</div>
              <span style={{
                fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: f.color,
                border: `1px solid ${f.color}40`, borderRadius: 4, padding: '2px 8px',
                letterSpacing: '0.1em',
              }}>{f.tag}</span>
            </div>
            <h3 style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 17, fontWeight: 600, color: '#e2e8f0', marginBottom: 12, letterSpacing: '-0.02em' }}>
              {f.title}
            </h3>
            <p style={{ color: '#64748b', fontSize: 14, lineHeight: 1.7 }}>{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
