const LINKS = {
  Platform: ['Threat Detection', 'Incident Response', 'Compliance', 'Attack Surface', 'Integrations', 'API Docs'],
  Solutions: ['Financial Services', 'Healthcare', 'Defense & Gov', 'Manufacturing', 'Critical Infrastructure'],
  Company: ['About Sentinel', 'Careers', 'Blog', 'Security Research', 'Press', 'Contact'],
  Legal: ['Privacy Policy', 'Terms of Service', 'DPA', 'Cookie Policy', 'Responsible Disclosure'],
}

export default function Footer() {
  return (
    <footer style={{
      borderTop: '1px solid rgba(0,217,255,0.08)',
      padding: '72px 24px 40px',
      background: '#07090e',
    }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr repeat(4, 1fr)', gap: 48, marginBottom: 64, flexWrap: 'wrap' }}>
          {/* Brand */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
              <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ width: 28, height: 28 }}>
                <polygon points="16,2 30,9 30,23 16,30 2,23 2,9" stroke="#00d9ff" strokeWidth="1.5" fill="rgba(0,217,255,0.06)" />
                <circle cx="16" cy="16" r="3" fill="#00d9ff" />
              </svg>
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 600, fontSize: 16, color: '#e2e8f0' }}>
                SENTINEL<span style={{ color: '#00d9ff' }}>.AI</span>
              </span>
            </div>
            <p style={{ color: '#64748b', fontSize: 14, lineHeight: 1.7, maxWidth: 280 }}>
              AI-native cybersecurity platform protecting 2,400+ enterprises from advanced threats in real time.
            </p>
            <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
              {['𝕏', 'in', '⌥'].map((icon, i) => (
                <div key={i} style={{
                  width: 36, height: 36, borderRadius: 8,
                  border: '1px solid rgba(0,217,255,0.15)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#64748b', fontSize: 14, cursor: 'pointer', transition: 'all 0.2s',
                }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(0,217,255,0.4)'; e.currentTarget.style.color = '#00d9ff' }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(0,217,255,0.15)'; e.currentTarget.style.color = '#64748b' }}
                >{icon}</div>
              ))}
            </div>
          </div>

          {/* Nav columns */}
          {Object.entries(LINKS).map(([section, links]) => (
            <div key={section}>
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#e2e8f0', fontWeight: 600, letterSpacing: '0.1em', marginBottom: 20 }}>
                {section.toUpperCase()}
              </div>
              {links.map(link => (
                <a key={link} href="#" style={{ display: 'block', color: '#64748b', fontSize: 14, textDecoration: 'none', marginBottom: 12, transition: 'color 0.2s' }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#94a3b8')}
                  onMouseLeave={e => (e.currentTarget.style.color = '#64748b')}
                >{link}</a>
              ))}
            </div>
          ))}
        </div>

        <div style={{ borderTop: '1px solid rgba(0,217,255,0.08)', paddingTop: 32, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
          <span style={{ color: '#64748b', fontSize: 13 }}>© 2026 Sentinel AI, Inc. All rights reserved.</span>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#34d399', boxShadow: '0 0 8px #34d399' }} />
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: '#64748b' }}>All systems operational</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
