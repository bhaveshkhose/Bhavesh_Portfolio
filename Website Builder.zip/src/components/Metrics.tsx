import { useEffect, useRef, useState } from 'react'

function useCountUp(target: number, duration = 2000, _suffix = '') {
  const [val, setVal] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const started = useRef(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true
        const start = performance.now()
        const tick = (now: number) => {
          const progress = Math.min((now - start) / duration, 1)
          const ease = 1 - Math.pow(1 - progress, 3)
          setVal(Math.round(ease * target))
          if (progress < 1) requestAnimationFrame(tick)
        }
        requestAnimationFrame(tick)
      }
    }, { threshold: 0.3 })
    observer.observe(el)
    return () => observer.disconnect()
  }, [target, duration])

  return { val, ref }
}

const STATS = [
  { raw: 500, suffix: 'M+', label: 'Events processed daily', sublabel: 'across cloud, endpoint, and network' },
  { raw: 99, suffix: '.7%', label: 'Threat detection rate', sublabel: 'verified by independent red teams' },
  { raw: 2400, suffix: '+', label: 'Enterprise clients', sublabel: 'in 47 countries' },
  { raw: 98, suffix: '%', label: 'Alert fidelity rate', sublabel: 'vs 38% industry average' },
]

function StatCard({ raw, suffix, label, sublabel }: typeof STATS[0]) {
  const { val, ref } = useCountUp(raw)

  return (
    <div ref={ref} style={{
      padding: '48px 40px',
      borderRight: '1px solid rgba(0,217,255,0.08)',
      flex: '1 1 220px',
      textAlign: 'center',
    }}>
      <div style={{
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 'clamp(44px, 5vw, 64px)',
        fontWeight: 700,
        color: '#00d9ff',
        lineHeight: 1,
        marginBottom: 8,
        letterSpacing: '-0.03em',
      }}>
        {val}{suffix}
      </div>
      <div style={{ color: '#e2e8f0', fontSize: 15, fontWeight: 500, marginBottom: 6 }}>{label}</div>
      <div style={{ color: '#64748b', fontSize: 13 }}>{sublabel}</div>
    </div>
  )
}

export default function Metrics() {
  return (
    <section style={{ background: '#0d1117', borderTop: '1px solid rgba(0,217,255,0.08)', borderBottom: '1px solid rgba(0,217,255,0.08)' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap' }}>
          {STATS.map((s, i) => (
            <StatCard key={i} {...s} />
          ))}
        </div>
      </div>
    </section>
  )
}
