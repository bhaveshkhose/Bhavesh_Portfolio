import Nav from './components/Nav'
import Hero from './components/Hero'
import TrustBar from './components/TrustBar'
import Features from './components/Features'
import Metrics from './components/Metrics'
import HowItWorks from './components/HowItWorks'
import Testimonials from './components/Testimonials'
import Pricing from './components/Pricing'
import CTABanner from './components/CTABanner'
import Footer from './components/Footer'

export default function App() {
  return (
    <div style={{ backgroundColor: '#07090e', minHeight: '100vh', fontFamily: "'Inter', sans-serif" }}>
      <Nav />
      <Hero />
      <TrustBar />
      <Features />
      <Metrics />
      <HowItWorks />
      <Testimonials />
      <Pricing />
      <CTABanner />
      <Footer />
    </div>
  )
}
